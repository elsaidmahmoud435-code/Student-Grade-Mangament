/**
 * Comprehensive Student Management System
 * Demonstrates Java Fundamentals, OOP, Exception Handling, and Code Quality
 * 
 * @author Grade Processing System
 * @version 1.0
 * @since 2024
 */
import java.util.*;
import java.text.DecimalFormat;

public class Student {
    // Data Types & Variables - Proper variable declarations and final usage
    private final String studentId;           // Final variable - cannot be changed
    private String firstName;
    private String lastName;
    private ArrayList<Double> grades;         // Collection for multiple grades
    private String letterGrade;
    private double gpa;
    
    // Static final constants - best practice
    private static final double GRADE_A_THRESHOLD = 90.0;
    private static final double GRADE_B_THRESHOLD = 80.0;
    private static final double GRADE_C_THRESHOLD = 70.0;
    private static final double GRADE_D_THRESHOLD = 60.0;
    private static final int MAX_GRADE = 100;
    private static final int MIN_GRADE = 0;
    
    /**
     * Constructor with comprehensive validation
     * Demonstrates Exception Handling and proper OOP implementation
     */
    public Student(String firstName, String lastName, String studentId) {
        // Input validation with exception handling
        if (firstName == null || firstName.trim().isEmpty()) {
            throw new IllegalArgumentException("First name cannot be null or empty");
        }
        if (lastName == null || lastName.trim().isEmpty()) {
            throw new IllegalArgumentException("Last name cannot be null or empty");
        }
        if (studentId == null || studentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Student ID cannot be null or empty");
        }
        
        // String Operations - String manipulation and formatting
        this.firstName = firstName.trim().toLowerCase();
        this.firstName = Character.toUpperCase(this.firstName.charAt(0)) + this.firstName.substring(1);
        this.lastName = lastName.trim().toLowerCase();
        this.lastName = Character.toUpperCase(this.lastName.charAt(0)) + this.lastName.substring(1);
        this.studentId = studentId.toUpperCase().trim();
        this.grades = new ArrayList<>();
        this.gpa = 0.0;
    }
    
    /**
     * Adds a grade with validation
     * Demonstrates Control Structures, Operators, and Exception Handling
     */
    public void addGrade(double grade) throws IllegalArgumentException {
        // Relational and conditional operators
        if (grade < MIN_GRADE || grade > MAX_GRADE) {
            throw new IllegalArgumentException(
                String.format("Grade %.2f is invalid. Must be between %d and %d", 
                grade, MIN_GRADE, MAX_GRADE));
        }
        grades.add(grade);
        updateGPA(); // Recalculate GPA when grades change
    }
    
    /**
     * Demonstrates Loops, Arrays/ArrayLists, and Math operations
     */
    public double calculateAverage() {
        if (grades.isEmpty()) {
            return 0.0;
        }
        
        double sum = 0.0;
        // Enhanced for loop - appropriate loop selection
        for (Double grade : grades) {
            sum += grade; // Arithmetic operator
        }
        return sum / grades.size(); // Arithmetic operators
    }
    
    /**
     * Demonstrates Math & Random operations
     */
    public void generateRandomGrades(int count) {
        Random random = new Random();
        for (int i = 0; i < count; i++) { // Traditional for loop
            // Math operations - generate random grades between 60-100
            double randomGrade = MIN_GRADE + (random.nextDouble() * (MAX_GRADE - MIN_GRADE));
            // Round to 2 decimal places using Math
            randomGrade = Math.round(randomGrade * 100.0) / 100.0;
            try {
                addGrade(randomGrade);
            } catch (IllegalArgumentException e) {
                System.err.println("Error generating grade: " + e.getMessage());
            }
        }
    }
    
    /**
     * Demonstrates Control Structures and Decision statements
     */
    public String determineLetterGrade(double average) {
        // Conditional operators and decision statements
        if (average >= GRADE_A_THRESHOLD) {
            letterGrade = "A";
        } else if (average >= GRADE_B_THRESHOLD) {
            letterGrade = "B";
        } else if (average >= GRADE_C_THRESHOLD) {
            letterGrade = "C";
        } else if (average >= GRADE_D_THRESHOLD) {
            letterGrade = "D";
        } else {
            letterGrade = "F";
        }
        return letterGrade;
    }
    
    /**
     * Updates GPA based on current grades
     * Demonstrates method organization and calculations
     */
    private void updateGPA() {
        if (!grades.isEmpty()) {
            gpa = calculateAverage() / 25.0; // Convert to 4.0 scale
            gpa = Math.min(gpa, 4.0); // Cap at 4.0
        }
    }
    
    /**
     * String Operations - comprehensive string manipulation and formatting
     */
    public String getFormattedStudentInfo() {
        DecimalFormat df = new DecimalFormat("#.##");
        StringBuilder info = new StringBuilder();
        
        // String concatenation and formatting
        info.append("=".repeat(50)).append("\n");
        info.append("STUDENT INFORMATION\n");
        info.append("=".repeat(50)).append("\n");
        info.append(String.format("Name: %s, %s\n", lastName, firstName));
        info.append(String.format("Student ID: %s\n", studentId));
        info.append(String.format("Number of Grades: %d\n", grades.size()));
        
        if (!grades.isEmpty()) {
            info.append(String.format("Average: %s\n", df.format(calculateAverage())));
            info.append(String.format("Letter Grade: %s\n", determineLetterGrade(calculateAverage())));
            info.append(String.format("GPA: %s/4.0\n", df.format(gpa)));
            info.append("Grades: ");
            for (int i = 0; i < grades.size(); i++) {
                info.append(df.format(grades.get(i)));
                if (i < grades.size() - 1) info.append(", ");
            }
            info.append("\n");
        } else {
            info.append("No grades recorded\n");
        }
        info.append("=".repeat(50));
        return info.toString();
    }
    
    /**
     * Demonstrates comparison operators and object comparison
     */
    public boolean isHonorStudent() {
        return !grades.isEmpty() && calculateAverage() >= 85.0;
    }
    
    /**
     * Demonstrates Arrays manipulation - converts ArrayList to array
     */
    public double[] getGradesAsArray() {
        double[] gradesArray = new double[grades.size()];
        for (int i = 0; i < grades.size(); i++) {
            gradesArray[i] = grades.get(i);
        }
        return gradesArray;
    }
    
    // Getters and Setters - Proper encapsulation
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getStudentId() { return studentId; } // No setter - final field
    public ArrayList<Double> getGrades() { return new ArrayList<>(grades); } // Defensive copy
    public double getGPA() { return gpa; }
    
    public void setFirstName(String firstName) {
        if (firstName != null && !firstName.trim().isEmpty()) {
            this.firstName = firstName.trim();
        }
    }
    
    public void setLastName(String lastName) {
        if (lastName != null && !lastName.trim().isEmpty()) {
            this.lastName = lastName.trim();
        }
    }
    
    /**
     * Override toString for better object representation
     */
    @Override
    public String toString() {
        return String.format("%s, %s (ID: %s)", lastName, firstName, studentId);
    }
    
    /**
     * Override equals for proper object comparison
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Student student = (Student) obj;
        return Objects.equals(studentId, student.studentId);
    }
    
    /**
     * Override hashCode to work with equals
     */
    @Override
    public int hashCode() {
        return Objects.hash(studentId);
    }
}