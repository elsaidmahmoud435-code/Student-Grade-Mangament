/**
 * Comprehensive Grade Management System
 * Demonstrates advanced Java concepts including Arrays, Exception Handling, 
 * Math operations, String formatting, and comprehensive data analysis
 * 
 * @author Grade Processing System
 * @version 2.0
 */
import java.util.*;
import java.text.DecimalFormat;

public class GradeManager {
    // Final constants for grade boundaries and validation
    private static final double MIN_VALID_GRADE = 0.0;
    private static final double MAX_VALID_GRADE = 100.0;
    private static final int DEFAULT_PRECISION = 2;
    private final DecimalFormat formatter;
    
    // Core data storage - demonstrating proper encapsulation
    private double[] gradeList;
    private double classAverage;
    private boolean averageCalculated;
    private String courseName;
    private final Date creationDate;
    
    // Statistics tracking - demonstrating comprehensive data analysis
    private double standardDeviation;
    private double median;
    private double highestGrade;
    private double lowestGrade;
    
    /**
     * Enhanced constructor with validation and exception handling
     */
    public GradeManager(double[] grades, String courseName) throws IllegalArgumentException {
        if (grades == null || grades.length == 0) {
            throw new IllegalArgumentException("Grade array cannot be null or empty");
        }
        if (courseName == null || courseName.trim().isEmpty()) {
            throw new IllegalArgumentException("Course name cannot be null or empty");
        }
        
        // Validate all grades using control structures and operators
        for (int i = 0; i < grades.length; i++) {
            if (grades[i] < MIN_VALID_GRADE || grades[i] > MAX_VALID_GRADE) {
                throw new IllegalArgumentException(
                    String.format("Invalid grade %.2f at position %d. Must be between %.1f and %.1f",
                    grades[i], i, MIN_VALID_GRADE, MAX_VALID_GRADE));
            }
        }
        
        // String operations - proper formatting and manipulation
        this.courseName = courseName.trim().toUpperCase();
        this.gradeList = Arrays.copyOf(grades, grades.length); // Defensive copy
        this.classAverage = 0.0;
        this.averageCalculated = false;
        this.creationDate = new Date();
        this.formatter = new DecimalFormat("#.##");
        
        // Initialize statistics
        initializeStatistics();
    }
    
    /**
     * Overloaded constructor for convenience
     */
    public GradeManager(double[] grades) throws IllegalArgumentException {
        this(grades, "UNKNOWN_COURSE");
    }
    
    /**
     * Calculate class average - demonstrating loops and mathematical operations
     */
    public void calcAverage() {
        if (gradeList.length == 0) return;
        
        double sum = 0.0;
        // Traditional for loop with arithmetic operations
        for (int i = 0; i < gradeList.length; i++) {
            sum += gradeList[i]; // Addition operator
        }
        classAverage = sum / gradeList.length; // Division operator
        averageCalculated = true;
    }
    
    /**
     * Advanced statistical calculations - Math & Random operations
     */
    public void calculateStatistics() {
        if (gradeList.length == 0) return;
        
        calcAverage(); // Ensure average is calculated
        
        // Find min and max using comparison operators
        highestGrade = gradeList[0];
        lowestGrade = gradeList[0];
        
        for (double grade : gradeList) { // Enhanced for loop
            if (grade > highestGrade) highestGrade = grade; // Relational operator
            if (grade < lowestGrade) lowestGrade = grade;   // Relational operator
        }
        
        // Calculate standard deviation using Math operations
        double sumSquaredDifferences = 0.0;
        for (double grade : gradeList) {
            double difference = grade - classAverage;
            sumSquaredDifferences += Math.pow(difference, 2); // Math.pow operation
        }
        standardDeviation = Math.sqrt(sumSquaredDifferences / gradeList.length); // Math.sqrt operation
        
        // Calculate median
        calculateMedian();
    }
    
    /**
     * Calculate median using array manipulation and sorting
     */
    private void calculateMedian() {
        // Arrays manipulation - create copy and sort
        double[] sortedGrades = Arrays.copyOf(gradeList, gradeList.length);
        Arrays.sort(sortedGrades);
        
        int length = sortedGrades.length;
        if (length % 2 == 0) { // Conditional operator for even/odd check
            // Even number of elements - average of middle two
            int mid1 = length / 2 - 1;
            int mid2 = length / 2;
            median = (sortedGrades[mid1] + sortedGrades[mid2]) / 2.0;
        } else {
            // Odd number of elements - middle element
            median = sortedGrades[length / 2];
        }
    }
    
    /**
     * Comprehensive report generation with string operations and formatting
     */
    public String generateReport() {
        // Ensure all calculations are up to date
        calculateStatistics();
        
        StringBuilder report = new StringBuilder();
        
        // String concatenation and formatting operations
        report.append("=".repeat(60)).append("\n");
        report.append(String.format("GRADE ANALYSIS REPORT - %s\n", courseName));
        report.append("=".repeat(60)).append("\n");
        report.append(String.format("Generated on: %s\n", creationDate.toString()));
        report.append(String.format("Total Students: %d\n", gradeList.length));
        report.append("-".repeat(60)).append("\n");
        
        // Statistical information with proper formatting
        report.append("STATISTICAL SUMMARY:\n");
        report.append(String.format("Class Average: %s\n", formatter.format(classAverage)));
        report.append(String.format("Median Grade: %s\n", formatter.format(median)));
        report.append(String.format("Highest Grade: %s\n", formatter.format(highestGrade)));
        report.append(String.format("Lowest Grade: %s\n", formatter.format(lowestGrade)));
        report.append(String.format("Standard Deviation: %s\n", formatter.format(standardDeviation)));
        report.append(String.format("Grade Range: %s\n", formatter.format(highestGrade - lowestGrade)));
        
        // Grade distribution analysis using control structures
        report.append("\nGRADE DISTRIBUTION:\n");
        report.append(generateGradeDistribution());
        
        report.append("\nALL GRADES:\n");
        report.append(formatAllGrades());
        report.append("=".repeat(60));
        
        return report.toString();
    }
    
    /**
     * Generate grade distribution using control structures and operators
     */
    private String generateGradeDistribution() {
        int countA = 0, countB = 0, countC = 0, countD = 0, countF = 0;
        
        // Count grades in each category using decision statements
        for (double grade : gradeList) {
            if (grade >= 90) {
                countA++; // Increment operator
            } else if (grade >= 80) {
                countB++;
            } else if (grade >= 70) {
                countC++;
            } else if (grade >= 60) {
                countD++;
            } else {
                countF++;
            }
        }
        
        // Calculate percentages using arithmetic operations
        int total = gradeList.length;
        StringBuilder distribution = new StringBuilder();
        distribution.append(String.format("A (90-100): %d students (%.1f%%)\n", 
            countA, (countA * 100.0 / total)));
        distribution.append(String.format("B (80-89):  %d students (%.1f%%)\n", 
            countB, (countB * 100.0 / total)));
        distribution.append(String.format("C (70-79):  %d students (%.1f%%)\n", 
            countC, (countC * 100.0 / total)));
        distribution.append(String.format("D (60-69):  %d students (%.1f%%)\n", 
            countD, (countD * 100.0 / total)));
        distribution.append(String.format("F (0-59):   %d students (%.1f%%)\n", 
            countF, (countF * 100.0 / total)));
        
        return distribution.toString();
    }
    
    /**
     * Format all grades for display using loops and string operations
     */
    private String formatAllGrades() {
        StringBuilder allGrades = new StringBuilder();
        int gradesPerLine = 10;
        
        for (int i = 0; i < gradeList.length; i++) {
            allGrades.append(formatter.format(gradeList[i]));
            
            if (i < gradeList.length - 1) {
                allGrades.append(", ");
            }
            
            // New line every 10 grades for better formatting
            if ((i + 1) % gradesPerLine == 0 && i < gradeList.length - 1) {
                allGrades.append("\n");
            }
        }
        allGrades.append("\n");
        return allGrades.toString();
    }
    
    /**
     * Add new grade with validation - demonstrating exception handling
     */
    public void addGrade(double newGrade) throws IllegalArgumentException {
        if (newGrade < MIN_VALID_GRADE || newGrade > MAX_VALID_GRADE) {
            throw new IllegalArgumentException(
                String.format("Grade %.2f is invalid. Must be between %.1f and %.1f",
                newGrade, MIN_VALID_GRADE, MAX_VALID_GRADE));
        }
        
        // Array manipulation - resize array to accommodate new grade
        double[] newGradeList = new double[gradeList.length + 1];
        System.arraycopy(gradeList, 0, newGradeList, 0, gradeList.length);
        newGradeList[gradeList.length] = newGrade;
        gradeList = newGradeList;
        
        // Mark statistics as needing recalculation
        averageCalculated = false;
    }
    
    /**
     * Generate random test grades - Math & Random operations
     */
    public static double[] generateRandomGrades(int count, double minGrade, double maxGrade) {
        Random random = new Random();
        double[] randomGrades = new double[count];
        
        for (int i = 0; i < count; i++) {
            // Math operations for random number generation
            double randomGrade = minGrade + (random.nextDouble() * (maxGrade - minGrade));
            randomGrades[i] = Math.round(randomGrade * 100.0) / 100.0; // Round to 2 decimals
        }
        
        return randomGrades;
    }
    
    /**
     * Check if class performance is above threshold - comparison operations
     */
    public boolean isHighPerformingClass(double threshold) {
        if (!averageCalculated) calcAverage();
        return classAverage >= threshold && standardDeviation <= 15.0; // Logical AND operator
    }
    
    /**
     * Initialize statistics to default values
     */
    private void initializeStatistics() {
        standardDeviation = 0.0;
        median = 0.0;
        highestGrade = 0.0;
        lowestGrade = 0.0;
    }
    
    // Getters demonstrating proper encapsulation
    public double getClassAverage() {
        if (!averageCalculated) calcAverage();
        return classAverage;
    }
    
    public double[] getGradeList() {
        return Arrays.copyOf(gradeList, gradeList.length); // Defensive copy
    }
    
    public String getCourseName() { return courseName; }
    public double getStandardDeviation() { return standardDeviation; }
    public double getMedian() { return median; }
    public double getHighestGrade() { return highestGrade; }
    public double getLowestGrade() { return lowestGrade; }
    public int getStudentCount() { return gradeList.length; }
    
    /**
     * Override toString for better object representation
     */
    @Override
    public String toString() {
        return String.format("GradeManager[Course: %s, Students: %d, Average: %.2f]",
            courseName, gradeList.length, getClassAverage());
    }
}