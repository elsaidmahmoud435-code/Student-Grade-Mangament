import java.util.List;
import java.util.Map;
public class ReportGenerator {
    
private DataAnalyzer dataAnalyzer;
private Formatter  formatter;
private Exporter exporter;

   public ReportGenerator(DataAnalyzer dataAnalyzer, Formatter formatter, Exporter exporter) {
       this.dataAnalyzer = dataAnalyzer;
       this.formatter = formatter;
       this.exporter = exporter;
   }

  public String generateReport(List<DataRecord> dataRecords, String formatType, String exportPath) {
    Map<String, Double> statistics = dataAnalyzer.calculateStatistics(dataRecords);
    String formattedReport = formatter.format(statistics);
    
    exporter.export(formattedReport, exportPath);
    
    return "Report generated successfully at: " + exportPath;
  }
  public interface DataAnalyzer {
      Map<String, Double> calculateStatistics(List<DataRecord> dataRecords);
  }
  public interface Formatter {
      String format(Map<String, Double> statistics);
  }

  public interface Exporter {
      void export(String data, String filePath);
  }
  public static class DataRecord {
      private Map<String, Object> values;

      public DataRecord(Map<String, Object> values) {
          this.values = values;
      }

      public Map<String, Object> getValues() {
          return values;
      }
  }

  

}