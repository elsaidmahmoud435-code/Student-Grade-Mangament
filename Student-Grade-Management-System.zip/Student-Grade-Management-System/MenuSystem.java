/**
 * Comprehensive Menu System for Student Management
 * Demonstrates Java I/O, Collections, String Operations, Exception Handling,
 * Control Structures, and comprehensive user interaction management
 * 
 * @author Grade Processing System
 * @version 2.0
 */
import java.util.*;
import java.io.*;

public class MenuSystem {
    // Collections management - ArrayList for dynamic student storage
    private ArrayList<Student> students;
    private ArrayList<GradeManager> courses;
    private Scanner scanner;
    private final String MENU_SEPARATOR = "=".repeat(50);
    private final String SUB_SEPARATOR = "-".repeat(30);
    
    // Static final constants for menu options
    private static final int ADD_STUDENT = 1;
    private static final int REMOVE_STUDENT = 2;
    private static final int VIEW_STUDENT = 3;
    private static final int UPDATE_STUDENT = 4;
    private static final int ADD_GRADE = 5;
    private static final int GENERATE_REPORT = 6;
    private static final int RANDOM_DATA = 7;
    private static final int EXIT = 8;
    
    /**
     * Constructor with proper initialization and exception handling
     */
    public MenuSystem() {
        this.students = new ArrayList<>();
        this.courses = new ArrayList<>();
        this.scanner = new Scanner(System.in);
        initializeSystem();
    }
    
    /**
     * Initialize system with sample data - demonstrates various Java concepts
     */
    private void initializeSystem() {
        // String operations and exception handling
        try {
            // Add sample students with proper error handling
            addStudent(new Student("John", "Doe", "STU001"));
            addStudent(new Student("Jane", "Smith", "STU002"));
            addStudent(new Student("Bob", "Johnson", "STU003"));
            
            // Add some random grades using Math & Random operations
            Random random = new Random();
            for (Student student : students) {
                int numGrades = 3 + random.nextInt(5); // 3-7 grades per student
                for (int i = 0; i < numGrades; i++) {
                    double grade = 60 + (random.nextDouble() * 40); // Grades between 60-100
                    student.addGrade(Math.round(grade * 100.0) / 100.0);
                }
            }
            
            // Create sample course with random grades
            double[] courseGrades = GradeManager.generateRandomGrades(25, 65.0, 98.0);
            courses.add(new GradeManager(courseGrades, "Computer Science 101"));
            
        } catch (Exception e) {
            System.err.println("Error initializing system: " + e.getMessage());
        }
    }
    
    /**
     * Main menu display and control - demonstrates loops and control structures
     */
    public void displayMainMenu() {
        boolean running = true;
        
        // Main application loop
        while (running) {
            try {
                printMainMenuOptions();
                int choice = getMenuChoice();
                
                // Control structures - switch statement for menu navigation
                switch (choice) {
                    case ADD_STUDENT:
                        handleAddStudent();
                        break;
                    case REMOVE_STUDENT:
                        handleRemoveStudent();
                        break;
                    case VIEW_STUDENT:
                        handleViewStudent();
                        break;
                    case UPDATE_STUDENT:
                        handleUpdateStudent();
                        break;
                    case ADD_GRADE:
                        handleAddGrade();
                        break;
                    case GENERATE_REPORT:
                        handleGenerateReport();
                        break;
                    case RANDOM_DATA:
                        handleGenerateRandomData();
                        break;
                    case EXIT:
                        running = false;
                        System.out.println("Thank you for using the Grade Processing System!");
                        break;
                    default:
                        System.err.println("Invalid choice. Please try again.");
                }
                
                if (running) {
                    System.out.println("\nPress Enter to continue...");
                    scanner.nextLine();
                }
                
            } catch (Exception e) {
                System.err.println("An error occurred: " + e.getMessage());
                scanner.nextLine(); // Clear the buffer
            }
        }
    }
    
    /**
     * String operations - formatted menu display
     */
    private void printMainMenuOptions() {
        StringBuilder menu = new StringBuilder();
        
        menu.append("\n").append(MENU_SEPARATOR).append("\n");
        menu.append("        STUDENT GRADE MANAGEMENT SYSTEM\n");
        menu.append(MENU_SEPARATOR).append("\n");
        menu.append(String.format("%-2d. Add New Student\n", ADD_STUDENT));
        menu.append(String.format("%-2d. Remove Student\n", REMOVE_STUDENT));
        menu.append(String.format("%-2d. View Student Details\n", VIEW_STUDENT));
        menu.append(String.format("%-2d. Update Student Information\n", UPDATE_STUDENT));
        menu.append(String.format("%-2d. Add Grade to Student\n", ADD_GRADE));
        menu.append(String.format("%-2d. Generate Course Report\n", GENERATE_REPORT));
        menu.append(String.format("%-2d. Generate Random Test Data\n", RANDOM_DATA));
        menu.append(String.format("%-2d. Exit\n", EXIT));
        menu.append(SUB_SEPARATOR).append("\n");
        menu.append(String.format("Total Students: %d | Total Courses: %d\n", 
            students.size(), courses.size()));
        menu.append(MENU_SEPARATOR);
        
        System.out.println(menu.toString());
    }
    
    /**
     * Input validation with exception handling
     */
    private int getMenuChoice() {
        System.out.print("Enter your choice (1-8): ");
        try {
            String input = scanner.nextLine().trim();
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            return -1; // Invalid input
        }
    }
    
    /**
     * Add student handler - demonstrates string operations and validation
     */
    private void handleAddStudent() {
        System.out.println("\n" + SUB_SEPARATOR);
        System.out.println("ADD NEW STUDENT");
        System.out.println(SUB_SEPARATOR);
        
        try {
            System.out.print("Enter first name: ");
            String firstName = scanner.nextLine().trim();
            
            System.out.print("Enter last name: ");
            String lastName = scanner.nextLine().trim();
            
            System.out.print("Enter student ID: ");
            String studentId = scanner.nextLine().trim().toUpperCase();
            
            // Check for duplicate student ID using comparison operations
            boolean duplicateFound = false;
            for (Student existingStudent : students) {
                if (existingStudent.getStudentId().equals(studentId)) {
                    duplicateFound = true;
                    break;
                }
            }
            
            if (duplicateFound) {
                System.err.println("Error: Student ID " + studentId + " already exists!");
                return;
            }
            
            Student newStudent = new Student(firstName, lastName, studentId);
            addStudent(newStudent);
            System.out.println("Student added successfully: " + newStudent.toString());
            
        } catch (IllegalArgumentException e) {
            System.err.println("Error adding student: " + e.getMessage());
        }
    }
    
    /**
     * Remove student handler - demonstrates collection manipulation
     */
    private void handleRemoveStudent() {
        if (students.isEmpty()) {
            System.out.println("No students found in the system.");
            return;
        }
        
        System.out.println("\n" + SUB_SEPARATOR);
        System.out.println("REMOVE STUDENT");
        System.out.println(SUB_SEPARATOR);
        
        displayStudentList();
        System.out.print("Enter student ID to remove: ");
        String studentId = scanner.nextLine().trim().toUpperCase();
        
        // Array/Collection manipulation - find and remove student
        Student studentToRemove = null;
        for (Student student : students) {
            if (student.getStudentId().equals(studentId)) {
                studentToRemove = student;
                break;
            }
        }
        
        if (studentToRemove != null) {
            students.remove(studentToRemove);
            System.out.println("Student removed successfully: " + studentToRemove.toString());
        } else {
            System.err.println("Student not found with ID: " + studentId);
        }
    }
    
    /**
     * View student handler - demonstrates formatted output and string operations
     */
    private void handleViewStudent() {
        if (students.isEmpty()) {
            System.out.println("No students found in the system.");
            return;
        }
        
        System.out.println("\n" + SUB_SEPARATOR);
        System.out.println("VIEW STUDENT DETAILS");
        System.out.println(SUB_SEPARATOR);
        
        displayStudentList();
        System.out.print("Enter student ID to view: ");
        String studentId = scanner.nextLine().trim().toUpperCase();
        
        Student foundStudent = findStudentById(studentId);
        if (foundStudent != null) {
            System.out.println(foundStudent.getFormattedStudentInfo());
        } else {
            System.err.println("Student not found with ID: " + studentId);
        }
    }
    
    /**
     * Update student handler - demonstrates object modification
     */
    private void handleUpdateStudent() {
        if (students.isEmpty()) {
            System.out.println("No students found in the system.");
            return;
        }
        
        System.out.println("\n" + SUB_SEPARATOR);
        System.out.println("UPDATE STUDENT INFORMATION");
        System.out.println(SUB_SEPARATOR);
        
        displayStudentList();
        System.out.print("Enter student ID to update: ");
        String studentId = scanner.nextLine().trim().toUpperCase();
        
        Student student = findStudentById(studentId);
        if (student == null) {
            System.err.println("Student not found with ID: " + studentId);
            return;
        }
        
        System.out.println("Current information: " + student.toString());
        System.out.print("Enter new first name (or press Enter to keep current): ");
        String newFirstName = scanner.nextLine().trim();
        if (!newFirstName.isEmpty()) {
            student.setFirstName(newFirstName);
        }
        
        System.out.print("Enter new last name (or press Enter to keep current): ");
        String newLastName = scanner.nextLine().trim();
        if (!newLastName.isEmpty()) {
            student.setLastName(newLastName);
        }
        
        System.out.println("Student updated successfully: " + student.toString());
    }
    
    /**
     * Add grade handler - demonstrates numeric input and validation
     */
    private void handleAddGrade() {
        if (students.isEmpty()) {
            System.out.println("No students found in the system.");
            return;
        }
        
        System.out.println("\n" + SUB_SEPARATOR);
        System.out.println("ADD GRADE TO STUDENT");
        System.out.println(SUB_SEPARATOR);
        
        displayStudentList();
        System.out.print("Enter student ID: ");
        String studentId = scanner.nextLine().trim().toUpperCase();
        
        Student student = findStudentById(studentId);
        if (student == null) {
            System.err.println("Student not found with ID: " + studentId);
            return;
        }
        
        try {
            System.out.print("Enter grade (0-100): ");
            String gradeInput = scanner.nextLine().trim();
            double grade = Double.parseDouble(gradeInput);
            
            student.addGrade(grade);
            System.out.println("Grade added successfully to " + student.toString());
            
        } catch (NumberFormatException e) {
            System.err.println("Invalid grade format. Please enter a numeric value.");
        } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    /**
     * Generate report handler - demonstrates comprehensive reporting
     */
    private void handleGenerateReport() {
        if (courses.isEmpty()) {
            System.out.println("No course data available for report generation.");
            return;
        }
        
        System.out.println("\n" + SUB_SEPARATOR);
        System.out.println("GENERATE COURSE REPORT");
        System.out.println(SUB_SEPARATOR);
        
        for (int i = 0; i < courses.size(); i++) {
            System.out.println((i + 1) + ". " + courses.get(i).toString());
        }
        
        try {
            System.out.print("Select course number: ");
            int courseIndex = Integer.parseInt(scanner.nextLine().trim()) - 1;
            
            if (courseIndex >= 0 && courseIndex < courses.size()) {
                GradeManager selectedCourse = courses.get(courseIndex);
                System.out.println(selectedCourse.generateReport());
            } else {
                System.err.println("Invalid course selection.");
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid input. Please enter a number.");
        }
    }
    
    /**
     * Generate random data handler - demonstrates Math & Random operations
     */
    private void handleGenerateRandomData() {
        System.out.println("\n" + SUB_SEPARATOR);
        System.out.println("GENERATE RANDOM TEST DATA");
        System.out.println(SUB_SEPARATOR);
        
        Random random = new Random();
        
        // Generate random students
        String[] firstNames = {"Alice", "Bob", "Charlie", "Diana", "Edward", "Fiona"};
        String[] lastNames = {"Anderson", "Brown", "Clark", "Davis", "Evans", "Foster"};
        
        int numStudents = 3 + random.nextInt(5); // 3-7 students
        for (int i = 0; i < numStudents; i++) {
            try {
                String firstName = firstNames[random.nextInt(firstNames.length)];
                String lastName = lastNames[random.nextInt(lastNames.length)];
                String studentId = "RND" + String.format("%03d", random.nextInt(1000));
                
                // Check for duplicate ID
                boolean duplicate = false;
                for (Student existingStudent : students) {
                    if (existingStudent.getStudentId().equals(studentId)) {
                        duplicate = true;
                        break;
                    }
                }
                
                if (!duplicate) {
                    Student newStudent = new Student(firstName, lastName, studentId);
                    newStudent.generateRandomGrades(3 + random.nextInt(5));
                    addStudent(newStudent);
                    System.out.println("Generated student: " + newStudent.toString());
                }
            } catch (Exception e) {
                System.err.println("Error generating student: " + e.getMessage());
            }
        }
        
        // Generate random course
        try {
            double[] randomGrades = GradeManager.generateRandomGrades(20 + random.nextInt(20), 50.0, 100.0);
            String courseName = "Random Course " + (courses.size() + 1);
            courses.add(new GradeManager(randomGrades, courseName));
            System.out.println("Generated course: " + courseName + " with " + randomGrades.length + " grades");
        } catch (Exception e) {
            System.err.println("Error generating course: " + e.getMessage());
        }
        
        System.out.println("\nRandom data generation completed!");
    }
    
    /**
     * Helper method to display student list - demonstrates formatting
     */
    private void displayStudentList() {
        System.out.println("Current Students:");
        for (int i = 0; i < students.size(); i++) {
            System.out.println((i + 1) + ". " + students.get(i).toString());
        }
        System.out.println();
    }
    
    /**
     * Helper method to find student by ID - demonstrates search operations
     */
    private Student findStudentById(String studentId) {
        for (Student student : students) {
            if (student.getStudentId().equalsIgnoreCase(studentId)) {
                return student;
            }
        }
        return null;
    }
    
    /**
     * Add student with validation - proper encapsulation
     */
    public void addStudent(Student student) throws IllegalArgumentException {
        if (student == null) {
            throw new IllegalArgumentException("Student cannot be null");
        }
        students.add(student);
    }
    
    /**
     * Get student count - simple getter
     */
    public int getStudentCount() {
        return students.size();
    }
    
    /**
     * Get students list - defensive copy for encapsulation
     */
    public ArrayList<Student> getStudents() {
        return new ArrayList<>(students);
    }
    
    /**
     * Cleanup resources - proper resource management
     */
    public void cleanup() {
        if (scanner != null) {
            scanner.close();
        }
    }
}
  
