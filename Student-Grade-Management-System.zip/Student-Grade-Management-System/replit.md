# Project Overview

## Overview

This appears to be a security-focused project containing Semgrep rules for code analysis. The repository includes custom security rules specifically designed to detect potential security vulnerabilities in Azure Bicep templates, focusing on proper handling of sensitive parameters like passwords, secrets, and tokens.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Static Code Analysis Framework
- **Primary Tool**: Semgrep for static code analysis
- **Rule Engine**: JSON-based rule definitions stored in `.config/.semgrep/`
- **Target Languages**: Generic pattern matching with specific focus on Bicep templates
- **Security Focus**: Emphasis on preventing sensitive information leakage

### Rule Structure Design
- **Pattern Matching**: Uses Semgrep's pattern-based detection system
- **Metadata Integration**: Comprehensive rule metadata including CWE mappings, OWASP references, and impact assessments
- **Severity Classification**: Configurable severity levels (WARNING, ERROR, etc.)
- **File Targeting**: Path-based inclusion/exclusion patterns for targeted scanning

### Security Rule Categories
- **Information Disclosure Prevention**: Rules to detect unmarked sensitive parameters
- **Compliance Mapping**: Integration with security frameworks (CWE, OWASP)
- **Technology-Specific Rules**: Specialized rules for Azure Bicep infrastructure-as-code

## External Dependencies

### Code Analysis Tools
- **Semgrep**: Core static analysis engine for pattern detection
- **Bicep**: Microsoft's domain-specific language for Azure Resource Manager templates

### Security Frameworks
- **CWE (Common Weakness Enumeration)**: Referenced for vulnerability classification
- **OWASP**: Used for security category mapping and best practices
- **Azure Documentation**: Referenced for Bicep-specific security guidelines

### Development Tools
- **JSON Schema**: For rule definition structure and validation
- **Regular Expressions**: For advanced pattern matching in metavariables